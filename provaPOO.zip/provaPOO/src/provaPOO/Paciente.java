package provaPOO;

public class Paciente extends Pessoa {
	
	
	public Paciente() {}
	
	public Paciente(String nome, int idade, char sexo, Endereco endereco) {
		super(nome,idade,sexo,endereco);
	}

	
	
	
}
	

