package provaPOO;

public class Enfermeiro extends Pessoa {
	
	public Enfermeiro(String nome, int idade, char sexo, Endereco endereco ) {
		super(nome,idade,sexo,endereco);
	}
	

}
	

