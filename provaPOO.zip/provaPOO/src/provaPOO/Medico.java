package provaPOO;

public class Medico extends Pessoa {
	
	public Medico(String nome, int idade, char sexo, Endereco endereco) {
		super(nome,idade,sexo,endereco);
	}
	
	
}
	

